from PIL import Image
src = Image.open('generated_images/generated_image_05245d86-9f26-46e8-9a11-b70204a99c8a_0.png').convert('RGBA')
sizes = {512:'kenoai-avatar.png', 192:'icon-192.png', 180:'apple-touch-icon.png', 64:'icon-64.png', 32:'favicon-32.png'}
for s, name in sizes.items():
    src.resize((s, s), Image.LANCZOS).save(f'public/{name}', optimize=True)
print('icons done')
