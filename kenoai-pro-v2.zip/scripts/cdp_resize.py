#!/usr/bin/env python3
"""Resize the browser viewport via CDP (Emulation.setDeviceMetricsOverride)."""
import asyncio, json, sys, urllib.request

WIDTH, HEIGHT = int(sys.argv[1]), int(sys.argv[2])
TARGET = sys.argv[3] if len(sys.argv) > 3 else None

def get(path):
    with urllib.request.urlopen(f'http://127.0.0.1:9222/json{path}') as r:
        return json.loads(r.read())

async def main():
    tabs = get('')
    ws_url = next((t['webSocketDebuggerUrl'] for t in tabs if (not TARGET or TARGET in t['url']) and t['type'] == 'page'), None)
    if not ws_url:
        print('no tab'); return
    try:
        import websockets
    except ImportError:
        print('NEED_WEBSOCKETS'); return
    async with websockets.connect(ws_url, max_size=10**7) as ws:
        await ws.send(json.dumps({'id': 1, 'method': 'Emulation.setDeviceMetricsOverride', 'params': {
            'width': WIDTH, 'height': HEIGHT, 'deviceScaleFactor': 1, 'mobile': WIDTH < 768
        }}))
        await ws.recv()
        print(f'viewport set to {WIDTH}x{HEIGHT}')

asyncio.run(main())
