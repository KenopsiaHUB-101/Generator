import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  readUsage, aggregateUsage, fmtNum, fmtMs, fmtWhen, clearUsage, store,
} from './lib.js';
import {
  IcoChart, IcoGrid, IcoChat, IcoRobot, IcoCredit, IcoSettings, IcoActivity,
  IcoPlus, IcoSearch, IcoTrash, IcoPencil, IcoDownload, IcoUpload, IcoCheck,
  IcoAlert, IcoSpark, IcoClock, IcoZap, IcoClose, IcoArrowDown, IcoPin,
} from './icons.jsx';

// ============================================================
// KenoAi Dashboard \u2014 SaaS-style analytics & control center.
// All data is local (localStorage) except live model/account info
// fetched from the backend. Nothing leaves this device.
// ============================================================

const TABS = [
  { id: 'overview',    label: 'Overview',       icon: IcoGrid },
  { id: 'analytics',   label: 'Analytics',      icon: IcoChart },
  { id: 'conversations', label: 'Conversations', icon: IcoChat },
  { id: 'models',      label: 'Models',         icon: IcoRobot },
  { id: 'billing',     label: 'Billing',        icon: IcoCredit },
  { id: 'settings',    label: 'Settings',       icon: IcoSettings },
  { id: 'activity',    label: 'Activity Log',   icon: IcoActivity },
];

function useLocal(key, initial) {
  const [v, setV] = useState(() => store.get(key, initial));
  useEffect(() => { store.set(key, v); }, [key, v]);
  return [v, setV];
}

/* ---------------- Tiny SVG chart primitives (no libraries) ---------------- */

function Spark({ data, w = 76, h = 24, stroke = 'var(--accent-500)' }) {
  if (!data || data.length < 2) return <svg width={w} height={h}><circle cx={w/2} cy={h/2} r="2" fill={stroke}/></svg>;
  const max = Math.max(...data, 1);
  const step = w / (data.length - 1);
  const pts = data.map((v, i) => `${(i * step).toFixed(1)},${(h - (v / max) * (h - 2) - 1).toFixed(1)}`);
  return (
    <svg width={w} height={h} aria-hidden>
      <polyline points={pts.join(' ')} fill="none" stroke={stroke} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" opacity="0.9"/>
    </svg>
  );
}

function AreaChart({ series, height = 170, onPoint }) {
  // series: [{day, requests, errors, tokens}]
  const w = 620;
  const pad = { l: 8, r: 8, t: 10, b: 22 };
  const max = Math.max(...series.map(s => s.requests), 1);
  const innerW = w - pad.l - pad.r;
  const innerH = height - pad.t - pad.b;
  const step = innerW / Math.max(1, series.length - 1);
  const x = i => pad.l + i * step;
  const y = v => pad.t + innerH - (v / max) * innerH;
  const line = series.map((s, i) => `${x(i).toFixed(1)},${y(s.requests).toFixed(1)}`).join(' ');
  const area = `${pad.l},${pad.t + innerH} ${line} ${pad.l + innerW},${pad.t + innerH}`;
  const [hover, setHover] = useState(null);
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="chart-svg" role="img" aria-label="Requests per day">
      <defs>
        <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--accent-500)" stopOpacity="0.35"/>
          <stop offset="100%" stopColor="var(--accent-500)" stopOpacity="0.02"/>
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map(f => (
        <line key={f} x1={pad.l} x2={pad.l + innerW} y1={pad.t + innerH * f} y2={pad.t + innerH * f} stroke="var(--border)" strokeDasharray="3 5" opacity="0.55"/>
      ))}
      <polygon points={area} fill="url(#areaFill)"/>
      <polyline points={line} fill="none" stroke="var(--accent-500)" strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round"/>
      {series.map((s, i) => (
        <g key={s.day}>
          {s.requests > 0 && <circle cx={x(i)} cy={y(s.requests)} r={hover === i ? 4 : 2.5} fill="var(--accent-500)"/>}
          <rect x={x(i) - step / 2} y={pad.t} width={step} height={innerH} fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}/>
        </g>
      ))}
      {hover != null && (
        <g className="chart-tip" transform={`translate(${Math.min(Math.max(x(hover), 60), w - 60)}, ${pad.t + 4})`}>
          <text x="0" y="8" textAnchor="middle" className="tip-day">{series[hover].day.slice(5)}</text>
          <text x="0" y="20" textAnchor="middle" className="tip-val">{series[hover].requests} req \u00b7 {fmtNum(series[hover].tokens)} tok</text>
        </g>
      )}
      {series.map((s, i) => (i % 2 === 0 || series.length <= 8) && (
        <text key={s.day} x={x(i)} y={height - 6} textAnchor="middle" className="chart-axis">{s.day.slice(5)}</text>
      ))}
    </svg>
  );
}

function Donut({ items, size = 150, thickness = 16 }) {
  // items: [{label, value, color}]
  const total = items.reduce((a, b) => a + b.value, 0);
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const segs = items.map((it, i) => ({ ...it, pct: total ? it.value / total : 0, color: PALETTE[i % PALETTE.length] }));
  let acc = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Share by model">
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--border)" strokeWidth={thickness} opacity="0.5"/>
      {segs.map(s => {
        if (!s.pct) return null;
        const dash = `${(s.pct * c).toFixed(1)} ${(c - s.pct * c).toFixed(1)}`;
        const off = -acc * c;
        acc += s.pct;
        return <circle key={s.label} cx={size/2} cy={size/2} r={r} fill="none" stroke={s.color} strokeWidth={thickness}
          strokeDasharray={dash} strokeDashoffset={off} transform={`rotate(-90 ${size/2} ${size/2})`} strokeLinecap="butt"/>;
      })}
    </svg>
  );
}

const PALETTE = ['#6366f1', '#a855f7', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6'];

/* ---------------- Dashboard root ---------------- */

function Dashboard({ sessions, onOpenChat, onDeleteChat, onRenameChat, theme, onToggleTheme, persona, onPersona, model, onModel, defaultPersona, onDefaultPersona, onClose }) {
  const [tab, setTab] = useLocal('kenoai_dash_tab', 'overview');
  const [usageVersion, setUsageVersion] = useState(0);
  const records = useMemo(() => readUsage(), [usageVersion]);
  const stats = useMemo(() => aggregateUsage(records), [records]);

  const refresh = useCallback(() => setUsageVersion(v => v + 1), []);

  return (
    <div className="dash" role="main" aria-label="Dashboard">
      <header className="dash-head">
        <div className="dh-title">
          <span className="dh-ico"><IcoChart /></span>
          <div>
            <h2>Dashboard</h2>
            <p className="dh-sub">Usage analytics \u00b7 models \u00b7 billing \u2014 stored locally on this device</p>
          </div>
        </div>
        <div className="dh-actions">
          <button type="button" className="btn-ghost" onClick={refresh} title="Refresh data">
            <IcoArrowDown /> Refresh
          </button>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close dashboard" title="Back to chat">
            <IcoClose />
          </button>
        </div>
      </header>

      <nav className="dash-tabs" role="tablist">
        {TABS.map(t => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            className={`dash-tab ${tab === t.id ? 'on' : ''}`}
            onClick={() => setTab(t.id)}
          >
            <t.icon /> {t.label}
            {t.id === 'activity' && stats.total.requests > 0 && <span className="tab-badge">{fmtNum(stats.total.requests)}</span>}
          </button>
        ))}
      </nav>

      <div className="dash-body scroll-y" key={tab}>
        {tab === 'overview' && <Overview stats={stats} records={records} sessions={sessions} onTab={setTab} refresh={refresh} />}
        {tab === 'analytics' && <Analytics stats={stats} />}
        {tab === 'conversations' && <Conversations sessions={sessions} onOpenChat={onOpenChat} onDeleteChat={onDeleteChat} onRenameChat={onRenameChat} />}
        {tab === 'models' && <Models model={model} onModel={onModel} />}
        {tab === 'billing' && <Billing stats={stats} />}
        {tab === 'settings' && <Settings theme={theme} onToggleTheme={onToggleTheme} persona={persona} onPersona={onPersona} defaultPersona={onDefaultPersona ? defaultPersona : persona} onDefaultPersona={onDefaultPersona || onPersona} refresh={refresh} />}
        {tab === 'activity' && <Activity records={records} refresh={refresh} />}
      </div>
    </div>
  );
}

/* ---------------- Overview ---------------- */

function Overview({ stats, records, sessions, onTab, refresh }) {
  const [account, setAccount] = useState(null);
  useEffect(() => {
    let alive = true;
    fetch('/api/account').then(r => r.json()).then(d => { if (alive) setAccount(d); }).catch(() => {});
    return () => { alive = false; };
  }, []);

  const delta = useMemo(() => {
    if (!stats.yesterday.requests) return stats.today.requests > 0 ? '+100%' : '0%';
    return ((stats.today.requests - stats.yesterday.requests) / stats.yesterday.requests * 100).toFixed(0) + '%';
  }, [stats]);

  const spark = stats.series.map(s => s.requests);
  const donutItems = stats.models.slice(0, 5).map(m => ({ label: m.id.split('/').pop(), value: m.requests }));
  const recent = [...records].reverse().slice(0, 8);
  const totalTokens = stats.total.prompt + stats.total.completion;

  return (
    <div className="dash-grid">
      <StatCard label="Requests (all time)" value={fmtNum(stats.total.requests)} delta={delta} deltaGood={delta !== '0%' && !delta.startsWith('-')} spark={spark} note={`${stats.total.errors} errors`} />
      <StatCard label="Tokens used" value={fmtNum(totalTokens)} spark={stats.series.map(s => s.tokens)} note={`${fmtNum(stats.total.prompt)} in \u00b7 ${fmtNum(stats.total.completion)} out`} />
      <StatCard label="Avg response" value={fmtMs(stats.avgMs)} spark={null} note="across successful requests" />
      <StatCard label="Conversations" value={String(sessions.length)} spark={null} note={`${sessions.filter(s => s.pinned).length} pinned \u00b7 ${stats.today.requests} requests today`} />

      <Card title="Requests \u2014 last 14 days" className="span-2" action={<button className="link-btn" onClick={() => onTab('analytics')}>Full analytics \u2192</button>}>
        <AreaChart series={stats.series} />
      </Card>

      <Card title="Top models" action={<button className="link-btn" onClick={() => onTab('models')}>Manage \u2192</button>}>
        {donutItems.length === 0 ? <Empty text="No data yet \u2014 send a message first." /> : (
          <div className="donut-row">
            <Donut items={donutItems} />
            <ul className="donut-legend">
              {stats.models.slice(0, 5).map((m, i) => (
                <li key={m.id}>
                  <span className="swatch" style={{ background: PALETTE[i % PALETTE.length] }} />
                  <span className="dl-label">{m.id}</span>
                  <span className="dl-val">{m.requests} \u00b7 {fmtNum(m.prompt + m.completion)} tok</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </Card>

      <Card title="Account" className="span-2" action={<button className="link-btn" onClick={() => onTab('billing')}>Billing \u2192</button>}>
        {!account ? <Empty text="Loading account\u2026" /> : !account.ok ? <Empty text={`Account info unavailable (${account.reason})`} /> : (
          <div className="acct-row">
            <div className="acct-item"><span className="ai-k">Key</span><span className="ai-v">{account.account.label}</span></div>
            <div className="acct-item"><span className="ai-k">Tier</span><span className="ai-v">{account.account.isFreeTier ? 'Free tier' : 'Paid'}</span></div>
            <div className="acct-item"><span className="ai-k">Spend</span><span className="ai-v">${Number(account.account.usage || 0).toFixed(4)}</span></div>
            <div className="acct-item"><span className="ai-k">Rate limit</span><span className="ai-v">{account.account.rateLimitRequests > 0 ? `${account.account.rateLimitRequests}/${account.account.rateLimitInterval || '10s'}` : 'default'}</span></div>
          </div>
        )}
      </Card>

      <Card title="Recent activity" className="span-2" action={<button className="link-btn" onClick={() => onTab('activity')}>View all \u2192</button>}>
        {recent.length === 0 ? <Empty text="Nothing yet. Chat with KenoAi and metrics appear here." /> : (
          <ul className="recent-list">
            {recent.map((r, i) => (
              <li key={r.ts + '-' + i}>
                <span className={`dot ${r.error ? 'err' : 'ok'}`} />
                <span className="rl-model">{(r.model || '').split('/').pop()}</span>
                <span className="rl-tok">{r.error ? 'error' : `${fmtNum((r.promptTokens || 0) + (r.completionTokens || 0))} tok \u00b7 ${fmtMs(r.ms)}`}</span>
                <span className="rl-when">{fmtWhen(r.ts)}</span>
      </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function StatCard({ label, value, delta, deltaGood, spark, note }) {
  return (
    <div className="stat-card">
      <div className="sc-top"><span className="sc-label">{label}</span>{spark && spark.some(v => v > 0) && <Spark data={spark} />}</div>
      <div className="sc-val">
        {value}
        {delta != null && <span className={`sc-delta ${deltaGood ? 'good' : 'bad'}`}>{delta}</span>}
      </div>
      {note && <div className="sc-note">{note}</div>}
    </div>
  );
}

/* ---------------- Analytics ---------------- */

function Analytics({ stats }) {
  const hourMax = Math.max(...stats.byHour, 1);
  const personaMax = Math.max(...stats.personas.map(p => p.requests), 1);
  const tokenSeries = stats.series;
  const tokenMax = Math.max(...tokenSeries.map(s => s.tokens), 1);
  const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return (
    <div className="dash-grid">
      <StatCard label="Requests today" value={String(stats.today.requests)} note={`${fmtNum(stats.today.prompt + stats.today.completion)} tokens today`} />
      <StatCard label="Avg response" value={fmtMs(stats.avgMs)} note="successful requests" />
      <StatCard label="Error rate" value={stats.errorRate.toFixed(1) + '%'} note={`${stats.total.errors} of ${stats.total.requests} requests`} />
      <StatCard label="Total tokens" value={fmtNum(stats.total.prompt + stats.total.completion)} note={`${fmtNum(stats.total.prompt)} in \u00b7 ${fmtNum(stats.total.completion)} out`} />

      <Card title="Activity by hour" className="span-2">
        <div className="hour-bars">
          {stats.byHour.map((v, h) => (
            <div key={h} className="hb-col" title={`${h}:00 \u2014 ${v} requests`}>
              <div className="hb-bar" style={{ height: `${(v / hourMax) * 100}%`, opacity: v ? 1 : 0.15 }} />
              {h % 3 === 0 && <span className="hb-lab">{h}</span>}
            </div>
          ))}
        </div>
      </Card>

      <Card title="Tokens by day">
        <div className="token-cols">
          {tokenSeries.map(s => (
            <div key={s.day} className="tc-col" title={`${s.day} \u2014 ${fmtNum(s.tokens)} tokens`}>
              <div className="tc-bar" style={{ height: `${(s.tokens / tokenMax) * 100}%`, opacity: s.tokens ? 1 : 0.12 }} />
            </div>
          ))}
        </div>
        <div className="tc-axis"><span>14d ago</span><span>today</span></div>
      </Card>

      <Card title="By persona">
        {stats.personas.length === 0 ? <Empty text="No persona data yet." /> : (
          <div className="persona-bars">
            {stats.personas.map(p => (
              <div key={p.id} className="pb-row">
                <span className="pb-label">{p.id}</span>
                <div className="pb-track"><div className="pb-fill" style={{ width: `${(p.requests / personaMax) * 100}%` }} /></div>
                <span className="pb-val">{p.requests}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Error breakdown" className="span-2">
        {stats.total.errors === 0 ? (
          <div className="ok-banner"><IcoCheck /> All {stats.total.requests} requests completed without errors. Flawless.</div>
        ) : (
          <div className="err-breakdown">
            <p>{stats.total.errors} of {stats.total.requests} requests failed ({stats.errorRate.toFixed(1)}%). Free-tier models can rate-limit under load \u2014 try another model from the Models tab or wait a minute.</p>
            <div className="pb-track big"><div className="pb-fill err" style={{ width: `${Math.min(100, stats.errorRate)}%` }} /></div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ---------------- Conversations ---------------- */

function Conversations({ sessions, onOpenChat, onDeleteChat, onRenameChat }) {
  const [q, setQ] = useState('');
  const [sort, setSort] = useLocal('kenoai_dash_sort', 'recent');
  const list = useMemo(() => {
    let out = [...sessions];
    const ql = q.trim().toLowerCase();
    if (ql) out = out.filter(s => (s.title || '').toLowerCase().includes(ql) || (s.messages || []).some(m => typeof m.content === 'string' && m.content.toLowerCase().includes(ql)));
    out.sort((a, b) => {
      if (sort === 'title') return (a.title || '').localeCompare(b.title || '');
      if (sort === 'messages') return (b.messages?.length || 0) - (a.messages?.length || 0);
      return (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0);
    });
    return out;
  }, [sessions, q, sort]);

  const exportChat = useCallback((s) => {
    const blob = new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `kenoai-${(s.title || 'chat').replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  }, []);

  return (
    <div className="dash-panel">
      <div className="conv-tools">
        <div className="search-box">
          <IcoSearch />
          <input type="search" placeholder="Search conversations\u2026" value={q} onChange={e => setQ(e.target.value)} aria-label="Search conversations" />
        </div>
        <div className="seg" role="tablist" aria-label="Sort">
          {[['recent', 'Recent'], ['messages', 'Messages'], ['title', 'A\u2013Z']].map(([id, lab]) => (
            <button key={id} type="button" className={`seg-btn ${sort === id ? 'on' : ''}`} onClick={() => setSort(id)}>{lab}</button>
          ))}
        </div>
      </div>
      <div className="table-wrap">
        <table className="dtable">
          <thead><tr>
            <th>Title</th><th>Messages</th><th>Updated</th><th>Created</th><th className="th-actions">Actions</th>
          </tr></thead>
          <tbody>
            {list.map(s => (
              <tr key={s.id}>
                <td className="td-title">
                  <button type="button" className="td-open" onClick={() => onOpenChat(s.id)}>{s.pinned && <IcoPin />}{s.title || 'Conversation'}</button>
                </td>
                <td>{s.messages?.length || 0}</td>
                <td>{fmtWhen(s.updatedAt || s.createdAt)}</td>
                <td>{new Date(s.createdAt || Date.now()).toLocaleDateString()}</td>
                <td className="td-actions">
                  <button type="button" className="mini-btn" title="Open" onClick={() => onOpenChat(s.id)}><IcoChat /></button>
                  <button type="button" className="mini-btn" title="Rename" onClick={() => onRenameChat(s.id)}><IcoPencil /></button>
                  <button type="button" className="mini-btn" title="Export JSON" onClick={() => exportChat(s)}><IcoDownload /></button>
                  <button type="button" className="mini-btn danger" title="Delete" onClick={() => onDeleteChat(s.id)}><IcoTrash /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {list.length === 0 && <Empty text="No conversations match your search." />}
      </div>
    </div>
  );
}

/* ---------------- Models ---------------- */

function Models({ model, onModel }) {
  const [models, setModels] = useState(null);
  const [serverDefault, setServerDefault] = useState(null);
  const [test, setTest] = useState(null); // {id, state: 'loading'|'ok'|'err', ms, text}
  const [q, setQ] = useState('');
  const [onlyFree, setOnlyFree] = useLocal('kenoai_dash_free_only', true);

  useEffect(() => {
    fetch('/api/models').then(r => r.json()).then(d => { setModels(d.models || []); setServerDefault(d.default); }).catch(() => setModels([]));
  }, []);

  const runTest = useCallback(async (id) => {
    setTest({ id, state: 'loading' });
    const t0 = performance.now();
    try {
      const r = await fetch('/api/ai-stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: id, messages: [{ role: 'user', content: 'Reply with the single word: online' }], persona: 'professional' }),
      });
      const reader = r.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      let out = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf('\n')) !== -1) {
          const line = buf.slice(0, nl).trim(); buf = buf.slice(nl + 1);
          if (!line.startsWith('data:')) continue;
          const payload = line.slice(5).trim();
          if (payload === '[DONE]') continue;
          try {
            const j = JSON.parse(payload);
            if (j.error) throw new Error(j.error);
            out += j?.choices?.[0]?.delta?.content || '';
          } catch (e) { if (String(e.message).includes('error')) throw e; }
        }
      }
      setTest({ id, state: 'ok', ms: Math.round(performance.now() - t0), text: out.trim().slice(0, 80) });
    } catch (err) {
      setTest({ id, state: 'err', text: String(err.message || err).slice(0, 120) });
    }
  }, []);

  const list = useMemo(() => {
    if (!models) return null;
    const ql = q.trim().toLowerCase();
    return models.filter(m => (!onlyFree || m.free) && (!ql || m.id.toLowerCase().includes(ql) || (m.label || '').toLowerCase().includes(ql)));
  }, [models, q, onlyFree]);

  return (
    <div className="dash-panel">
      <div className="conv-tools">
        <div className="search-box">
          <IcoSearch />
          <input type="search" placeholder="Search models\u2026" value={q} onChange={e => setQ(e.target.value)} aria-label="Search models" />
        </div>
        <label className="chk">
          <input type="checkbox" checked={onlyFree} onChange={e => setOnlyFree(e.target.checked)} />
          Free only
        </label>
      </div>
      {serverDefault && (
        <p className="hint-line">Server default: <code>{serverDefault}</code> {model === serverDefault ? '(active)' : `\u2014 your pick overrides it per request`}</p>
      )}
      {list === null ? <Empty text="Loading model catalogue\u2026" /> : (
        <div className="model-cards">
          {list.map(m => {
            const active = model === m.id;
            const t = test && test.id === m.id ? test : null;
            return (
              <div key={m.id} className={`model-card ${active ? 'active' : ''}`}>
                <div className="mc-head">
                  <div className="mc-title">{m.label}</div>
                  <span className={`badge ${m.free ? 'free' : 'paid'}`}>{m.free ? 'FREE' : 'PAID'}</span>
                </div>
                <div className="mc-id">{m.id}</div>
                <div className="mc-meta">
                  {m.image && <span className="chip-meta" title="Supports image input"><IcoUpload /> image</span>}
                  <span className="chip-meta" title="Context window"><IcoZap /> {m.ctx}</span>
                </div>
                <div className="mc-note">{m.note}</div>
                <div className="mc-actions">
                  <button type="button" className={`btn-sm ${active ? 'btn-current' : ''}`} disabled={active} onClick={() => onModel(m.id)}>
                    {active ? <><IcoCheck /> Active</> : 'Use this model'}
                  </button>
                  <button type="button" className="btn-sm ghost" onClick={() => runTest(m.id)} disabled={t?.state === 'loading'}>
                    {t?.state === 'loading' ? 'Testing\u2026' : 'Test live'}
                  </button>
                </div>
                {t && t.state === 'ok' && <div className="test-result ok"><IcoCheck /> {t.ms} ms \u2014 "{t.text}"</div>}
                {t && t.state === 'err' && <div className="test-result err"><IcoAlert /> {t.text}</div>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Billing ---------------- */

function Billing({ stats }) {
  const [account, setAccount] = useState(null);
  useEffect(() => {
    let alive = true;
    fetch('/api/account').then(r => r.json()).then(d => { if (alive) setAccount(d); }).catch(() => {});
    return () => { alive = false; };
  }, []);

  const daily = stats.series.slice(-7).map(s => s.requests);
  const dailyMax = Math.max(...daily, 1);
  const freeDailyCap = 50; // OpenRouter free tier guideline
  const todayPct = Math.min(100, (stats.today.requests / freeDailyCap) * 100);

  return (
    <div className="dash-grid">
      <Card title="Free tier \u2014 today" className="span-2">
        <div className="bill-hero">
          <div className="bill-main">
            <div className="bill-num">{stats.today.requests}<span className="bill-cap"> / ~{freeDailyCap} requests</span></div>
            <div className="pb-track big"><div className={`pb-fill ${todayPct > 80 ? 'warn' : ''}`} style={{ width: `${todayPct}%` }} /></div>
            <p className="hint-line">OpenRouter free models allow roughly 20 requests/minute and {freeDailyCap} requests/day if you have less than $10 lifetime credits. Paid models have no daily cap.</p>
          </div>
        </div>
        <div className="bill-week">
          {stats.series.slice(-7).map(s => (
            <div key={s.day} className="bw-col" title={`${s.day} \u2014 ${s.requests} requests`}>
              <div className="bw-bar" style={{ height: `${(s.requests / dailyMax) * 100}%`, opacity: s.requests ? 1 : 0.12 }} />
              <span className="bw-lab">{s.day.slice(5)}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Spend to date" className="span-2">
        {!account ? <Empty text="Loading account\u2026" /> : !account.ok ? <Empty text={`Account info unavailable (${account.reason})`} /> : (
          <div className="acct-row">
            <div className="acct-item"><span className="ai-k">Spend</span><span className="ai-v">${Number(account.account.usage || 0).toFixed(4)}</span></div>
            <div className="acct-item"><span className="ai-k">Limit</span><span className="ai-v">{account.account.limit == null ? 'no hard limit' : `$${account.account.limit}`}</span></div>
            <div className="acct-item"><span className="ai-k">Remaining</span><span className="ai-v">{account.account.limitRemaining == null ? '\u2014' : `$${account.account.limitRemaining.toFixed(4)}`}</span></div>
            <div className="acct-item"><span className="ai-k">Tier</span><span className="ai-v">{account.account.isFreeTier ? 'Free tier' : 'Paid'}</span></div>
            <div className="acct-item"><span className="ai-k">Key</span><span className="ai-v mono">{account.account.label}</span></div>
          </div>
        )}
      </Card>

      <Card title="Cost estimate (if paid)" className="span-2">
        <p className="hint-line">Your usage would cost about <b>${(stats.total.completion * 0.000004 + stats.total.prompt * 0.000001).toFixed(4)}</b> on typical paid-model pricing ($1/M in, $4/M out). With free models: <b>$0.00</b>.</p>
        <div className="acct-row">
          <div className="acct-item"><span className="ai-k">Input tokens</span><span className="ai-v">{fmtNum(stats.total.prompt)}</span></div>
          <div className="acct-item"><span className="ai-k">Output tokens</span><span className="ai-v">{fmtNum(stats.total.completion)}</span></div>
        </div>
      </Card>
    </div>
  );
}

/* ---------------- Settings ---------------- */

function Settings({ theme, onToggleTheme, persona, onPersona, defaultPersona, onDefaultPersona, refresh }) {
  const [confirmClear, setConfirmClear] = useState(false);
  const [msg, setMsg] = useState('');
  const fileRef = useRef(null);

  const exportAll = () => {
    const payload = {
      app: 'KenoAi', version: 2, exportedAt: new Date().toISOString(),
      sessions: store.get('kenoai_sessions_v2', []),
      settings: { theme: store.get('kenoai_theme', 'dark'), persona: store.get('kenoai_persona', 'professional') },
      usage: readUsage(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `kenoai-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    setMsg('Backup downloaded.');
  };

  const importAll = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    file.text().then(txt => {
      try {
        const data = JSON.parse(txt);
        if (!data || data.app !== 'KenoAi') throw new Error('Not a KenoAi backup');
        if (Array.isArray(data.sessions)) store.set('kenoai_sessions_v2', data.sessions);
        if (data.usage) store.set('kenoai_usage_v1', data.usage);
        if (data.settings?.theme) store.set('kenoai_theme', data.settings.theme);
        if (data.settings?.persona) store.set('kenoai_persona', data.settings.persona);
        setMsg(`Imported ${data.sessions?.length || 0} conversations and ${data.usage?.length || 0} usage records. Refresh the page to apply.`);
        refresh();
      } catch (err) {
        setMsg(`Import failed: ${err.message}`);
      }
    });
    e.target.value = '';
  };

  return (
    <div className="dash-grid">
      <Card title="Appearance">
        <div className="set-row">
          <div>
            <div className="set-k">Theme</div>
            <div className="set-sub">Dark by default, light available</div>
          </div>
          <button type="button" className="btn-sm" onClick={onToggleTheme}>{theme === 'dark' ? 'Switch to Light' : 'Switch to Dark'}</button>
        </div>
      </Card>

      <Card title="Persona">
        <div className="set-row">
          <div>
            <div className="set-k">Default persona</div>
            <div className="set-sub">Used for new conversations</div>
          </div>
          <select className="sel" value={defaultPersona} onChange={e => onDefaultPersona(e.target.value)} aria-label="Default persona">
            <option value="professional">Professional</option>
            <option value="programmer">Programmer</option>
            <option value="casual">Casual</option>
          </select>
        </div>
      </Card>

      <Card title="Data \u2014 export & backup" className="span-2">
        <div className="set-row">
          <div>
            <div className="set-sub">Download every conversation + usage record as JSON.</div>
          </div>
          <button type="button" className="btn-sm" onClick={exportAll}><IcoDownload /> Export backup</button>
        </div>
        <div className="set-row">
          <div>
            <div className="set-sub">Restore from a KenoAi backup file.</div>
          </div>
          <button type="button" className="btn-sm" onClick={() => fileRef.current?.click()}><IcoUpload /> Import backup</button>
          <input ref={fileRef} type="file" accept="application/json" hidden onChange={importAll} />
        </div>
        {msg && <div className="set-msg ok"><IcoCheck /> {msg}</div>}
      </Card>

      <Card title="Usage data" className="span-2">
        <div className="set-row">
          <div>
            <div className="set-k">Reset analytics</div>
            <div className="set-sub">Clears all recorded request metrics. Conversations are untouched.</div>
          </div>
          {!confirmClear ? (
            <button type="button" className="btn-sm danger" onClick={() => setConfirmClear(true)}><IcoTrash /> Clear usage data</button>
          ) : (
            <div className="confirm-inline">
              <button type="button" className="btn-sm ghost" onClick={() => setConfirmClear(false)}>Cancel</button>
              <button type="button" className="btn-sm danger" onClick={() => { clearUsage(); setConfirmClear(false); setMsg('Usage data cleared.'); refresh(); }}>Confirm clear</button>
            </div>
          )}
        </div>
      </Card>

      <Card title="About" className="span-2">
        <p className="hint-line">KenoAi Pro \u2014 React + Vite + Express, streaming from OpenRouter. All history and analytics live in your browser's localStorage: nothing is uploaded, no tracking, no account needed.</p>
      </Card>
    </div>
  );
}

/* ---------------- Activity log ---------------- */

function Activity({ records, refresh }) {
  const [filter, setFilter] = useState('all');
  const list = useMemo(() => {
    const out = [...records].reverse();
    return filter === 'errors' ? out.filter(r => r.error) : filter === 'ok' ? out.filter(r => !r.error) : out;
  }, [records, filter]);
  return (
    <div className="dash-panel">
      <div className="conv-tools">
        <div className="seg" role="tablist" aria-label="Filter">
          {[['all', 'All'], ['ok', 'Success'], ['errors', 'Errors']].map(([id, lab]) => (
            <button key={id} type="button" className={`seg-btn ${filter === id ? 'on' : ''}`} onClick={() => setFilter(id)}>{lab}</button>
          ))}
        </div>
        <button type="button" className="btn-sm ghost" onClick={refresh}><IcoArrowDown /> Refresh</button>
      </div>
      <div className="table-wrap">
        <table className="dtable">
          <thead><tr>
            <th>When</th><th>Model</th><th>Persona</th><th>Tokens</th><th>Duration</th><th>Status</th>
          </tr></thead>
          <tbody>
            {list.map((r, i) => (
              <tr key={(r.ts || 0) + '-' + i}>
                <td className="mono">{new Date(r.ts).toLocaleString()}</td>
                <td className="mono">{r.model}</td>
                <td>{r.persona || '\u2014'}</td>
                <td>{r.error ? '\u2014' : fmtNum((r.promptTokens || 0) + (r.completionTokens || 0))}</td>
                <td>{r.error ? '\u2014' : fmtMs(r.ms)}</td>
                <td>{r.error ? <span className="badge err">{typeof r.error === 'string' ? r.error.slice(0, 60) : 'error'}</span> : <span className="badge ok">ok</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {list.length === 0 && <Empty text="No activity recorded yet." />}
      </div>
    </div>
  );
}

function Card({ title, children, className = '', action = null }) {
  return (
    <section className={`dash-card ${className}`}>
      <div className="dc-head">
        <h3>{title}</h3>
        {action}
      </div>
      <div className="dc-body">{children}</div>
    </section>
  );
}

function Empty({ text }) {
  return <div className="dash-empty">{text}</div>;
}

export default memo(Dashboard);
