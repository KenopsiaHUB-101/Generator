// ============================================================
// KenoAi — shared utilities
// ============================================================

let counter = 0;
export const uid = () =>
  `${Date.now().toString(36)}-${(counter++).toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

export const API = '/api';

/** Compact localStorage wrapper that never throws (Safari private mode, quota). */
export const store = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  },
  remove(key) {
    try { localStorage.removeItem(key); } catch {}
  },
};

/** Trim history to the last N pairs to keep payloads + storage small. */
export function trimForApi(messages, maxPairs = 12) {
  if (messages.length <= maxPairs * 2 + 1) return messages;
  return messages.slice(-(maxPairs * 2));
}

/** Downscale + compress an image file to a data URL (max 1152px, ~85% quality). */
export function compressImage(file, maxDim = 1152, quality = 0.85) {
  return new Promise((resolve, reject) => {
    if (!/^image\//.test(file.type)) return reject(new Error('Not an image'));
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.max(1, Math.round(img.naturalWidth * scale));
        const h = Math.max(1, Math.round(img.naturalHeight * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0,  0, w, h);
        URL.revokeObjectURL(url);
        const type = /png|webp/.test(file.type) && canvas.toDataURL('image/webp').startsWith('data:image/webp')
          ? 'image/webp'
          : 'image/jpeg';
        resolve({ dataUrl: canvas.toDataURL(type, quality), w, h });
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Invalid image')); };
    img.src = url;
  });
}

/** Group sessions by recency buckets. */
export function groupSessions(sessions) {
  const now = Date.now();
  const DAY = 86400000;
  const buckets = [
    ['Pinned', []],
    ['Today', []],
    ['Yesterday', []],
    ['Previous 7 Days', []],
    ['Previous 30 Days', []],
    ['Older', []],
  ];
  for (const s of sessions) {
    if (s.pinned) { buckets[0][1].push(s); continue; }
    const age = now - (s.updatedAt || s.createdAt || s.id * 1 || now);
    if (age < DAY) buckets[1][1].push(s);
    else if (age < 2 * DAY) buckets[2][1].push(s);
    else if (age < 7 * DAY) buckets[3][1].push(s);
    else if (age < 30 * DAY) buckets[4][1].push(s);
    else buckets[5][1].push(s);
  }
  return buckets.filter(([, list]) => list.length > 0);
}

/** Split a raw SSE byte stream into JSON payloads. Handles chunks split across reads. */
export async function* sseLines(reader) {
  const decoder = new TextDecoder();
  let buf = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (line.startsWith('data:')) yield line.slice(5).trim();
    }
  }
  const rest = buf.trim();
  if (rest.startsWith('data:')) yield rest.slice(5).trim();
}

/** Extract the delta text from an OpenRouter-compatible chunk. */
export function deltaText(json) {
  return json?.choices?.[0]?.delta?.content || '';
}

/** Extract token usage from the final SSE chunk (needs stream_options.include_usage). */
export function chunkUsage(json) {
  return json?.usage || null;
}

// ============================================================
// Usage analytics \u2014 powers the Dashboard.
// One record per AI request, stored locally (never sent anywhere).
// ============================================================
const USAGE_KEY = 'kenoai_usage_v1';
const USAGE_CAP = 800; // hard cap \u2014 oldest entries pruned automatically

export function readUsage() {
  return store.get(USAGE_KEY, []);
}

/** Append a usage record { model, persona, ms, promptTokens, completionTokens, chars, error, ts }. */
export function recordUsage(entry) {
  const list = readUsage();
  list.push({ ts: Date.now(), ...entry });
  store.set(USAGE_KEY, list.slice(-USAGE_CAP));
  return list.length;
}

export function clearUsage() {
  store.remove(USAGE_KEY);
}

const dayKey = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

/** Aggregate raw records into dashboard-ready series. */
export function aggregateUsage(records) {
  const now = new Date();
  const todayKey = dayKey(now.getTime());
  const yest = dayKey(now.getTime() - 86400000);

  const total = { requests: 0, errors: 0, prompt: 0, completion: 0, ms: 0, chars: 0 };
  const today = { requests: 0, errors: 0, prompt: 0, completion: 0, ms: 0 };
  const yesterday = { requests: 0, errors: 0, prompt: 0, completion: 0, ms: 0 };
  const byModel = new Map();
  const byPersona = new Map();
  const byDay = new Map();   // dayKey -> {requests, errors, tokens}
  const byHour = new Array(24).fill(0);

  for (const r of records) {
    const pt = r.promptTokens || 0;
    const ct = r.completionTokens || 0;
    total.requests++;
    total.prompt += pt;
    total.completion += ct;
    total.chars += r.chars || 0;
    if (r.error) total.errors++;
    if (r.ms) total.ms += r.ms;

    const dk = dayKey(r.ts);
    const day = byDay.get(dk) || { requests: 0, errors: 0, tokens: 0 };
    day.requests++;
    day.tokens += pt + ct;
    if (r.error) day.errors++;
    byDay.set(dk, day);

    if (dk === todayKey) { today.requests++; today.prompt += pt; today.completion += ct; if (r.error) today.errors++; if (r.ms) today.ms += r.ms; }
    if (dk === yest) { yesterday.requests++; yesterday.errors++; if (!r.error) { yesterday.prompt += pt; yesterday.completion += ct; } }

    const m = byModel.get(r.model) || { requests: 0, errors: 0, prompt: 0, completion: 0 };
    m.requests++; m.prompt += pt; m.completion += ct; if (r.error) m.errors++;
    byModel.set(r.model, m);

    const p = byPersona.get(r.persona || 'professional') || { requests: 0, tokens: 0 };
    p.requests++; p.tokens += pt + ct;
    byPersona.set(r.persona || 'professional', p);

    byHour[new Date(r.ts).getHours()]++;
  }

  // 14-day series with zero-filled gaps
  const series = [];
  for (let i = 13; i >= 0; i--) {
    const dk = dayKey(now.getTime() - i * 86400000);
    const d = byDay.get(dk) || { requests: 0, errors: 0, tokens: 0 };
    series.push({ day: dk, ...d });
  }

  return {
    total, today, yesterday, series,
    models: [...byModel.entries()].map(([id, v]) => ({ id, ...v })).sort((a, b) => b.requests - a.requests),
    personas: [...byPersona.entries()].map(([id, v]) => ({ id, ...v })).sort((a, b) => b.requests - a.requests),
    byHour,
    avgMs: total.requests ? Math.round(total.ms / Math.max(1, total.requests - total.errors)) : 0,
    errorRate: total.requests ? (total.errors / total.requests) * 100 : 0,
  };
}

/** "3 s" / "1.2k tok" style compact formatting. */
export function fmtNum(n) {
  if (n == null) return '\u2014';
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e4 ? 0 : 1) + 'k';
  return String(Math.round(n));
}
export function fmtMs(ms) {
  if (ms == null || !ms) return '\u2014';
  if (ms < 1000) return Math.round(ms) + ' ms';
  return (ms / 1000).toFixed(1) + ' s';
}
export function fmtWhen(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return Math.floor(diff / 60000) + 'm ago';
  if (diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
  if (diff < 7 * 86400000) return Math.floor(diff / 86400000) + 'd ago';
  return new Date(ts).toLocaleDateString();
}
